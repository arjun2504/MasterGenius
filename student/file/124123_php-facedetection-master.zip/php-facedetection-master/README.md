PHP Face Detection
==================

This class detect one face in images. This is a pure PHP port of an existing JS code from Karthik Tharavaad.

Requirements
------------
PHP5 with GD

License
-------
GNU GPL v2 (See LICENSE.txt)
